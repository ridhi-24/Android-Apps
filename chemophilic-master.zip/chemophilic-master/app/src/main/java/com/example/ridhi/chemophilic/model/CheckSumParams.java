package com.example.ridhi.chemophilic.model;

public class CheckSumParams {
    private String MID;
    private String ORDER_ID;
    private String CUST_ID;
    private String MOBILE_NO;
    private String EMAIL;
    private String CHANNEL_ID;
    private String TXN_AMOUNT;
    private String WEBSITE;
    private String INDUSTRY_TYPE_ID;
    private String CALLBACK_URL;

    public CheckSumParams(String MID,String ORDER_ID, String CUST_ID, String MOBILE_NO, String EMAIL, String CHANNEL_ID, String TXN_AMOUNT, String WEBSITE, String INDUSTRY_TYPE_ID, String CALLBACK_URL) {
        this.MID = MID;
        this.ORDER_ID = ORDER_ID;
        this.CUST_ID = CUST_ID;
        this.MOBILE_NO = MOBILE_NO;
        this.EMAIL = EMAIL;
        this.CHANNEL_ID = CHANNEL_ID;
        this.TXN_AMOUNT = TXN_AMOUNT;
        this.WEBSITE = WEBSITE;
        this.INDUSTRY_TYPE_ID = INDUSTRY_TYPE_ID;
        this.CALLBACK_URL = CALLBACK_URL;
    }

    public String getMID() {
        return MID;
    }

    public String getORDER_ID() {
        return ORDER_ID;
    }

    public String getCUST_ID() {
        return CUST_ID;
    }

    public String getMOBILE_NO() {
        return MOBILE_NO;
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public String getCHANNEL_ID() {
        return CHANNEL_ID;
    }

    public String getTXN_AMOUNT() {
        return TXN_AMOUNT;
    }

    public String getWEBSITE() {
        return WEBSITE;
    }

    public String getINDUSTRY_TYPE_ID() {
        return INDUSTRY_TYPE_ID;
    }

    public String getCALLBACK_URL() {
        return CALLBACK_URL;
    }
}
