package com.example.ridhi.chemophilic.UI;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.ridhi.chemophilic.R;

public class SplashActivity extends AppCompatActivity {
    Thread thread;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences = getSharedPreferences("CRM-persist", MODE_PRIVATE);
    }

    protected void onResume() {
        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Intent intent = new Intent(getApplicationContext(), Course.class);
                startActivity(intent);
                finish();
            }
        });
        thread.start();
        super.onResume();
    }

    @Override
    protected void onPause() {
        thread = null;
        super.onPause();
    }
}
