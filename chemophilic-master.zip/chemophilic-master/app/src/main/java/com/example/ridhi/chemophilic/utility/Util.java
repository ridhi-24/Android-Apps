package com.example.ridhi.chemophilic.utility;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;

import com.example.ridhi.chemophilic.R;

public class Util {

    public static void setupToolbar(AppCompatActivity appCompatActivity, Toolbar toolbar, String title) {
        appCompatActivity.setSupportActionBar(toolbar);
        appCompatActivity.getSupportActionBar().setDisplayShowTitleEnabled(false);
// appCompatActivity. getSupportActionBar().setLogo(R.drawable.tatasky);
        appCompatActivity.getSupportActionBar().setDisplayUseLogoEnabled(true);
        Drawable drawable = ContextCompat.getDrawable(appCompatActivity, R.drawable.ic_more_vert_white_24dp);
        toolbar.setOverflowIcon(drawable);
        appCompatActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        appCompatActivity.getSupportActionBar().setDisplayShowHomeEnabled(true);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText(title);
// toolbar.setNavigationIcon();
    }

    public static void setupToolbarWithoutBack(AppCompatActivity appCompatActivity, Toolbar toolbar, String title) {
        appCompatActivity.setSupportActionBar(toolbar);
        appCompatActivity.getSupportActionBar().setDisplayShowTitleEnabled(false);
// appCompatActivity. getSupportActionBar().setLogo(R.drawable.tatasky);
        appCompatActivity.getSupportActionBar().setDisplayUseLogoEnabled(true);
        Drawable drawable = ContextCompat.getDrawable(appCompatActivity, R.drawable.ic_more_vert_white_24dp);
        toolbar.setOverflowIcon(drawable);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText(title);
// toolbar.setNavigationIcon();
    }

    public static void showProgress(ProgressDialog progressDialog, String message) {
        progressDialog.setIndeterminate(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(message);
        progressDialog.show();
    }

    public static void dismissProgress(ProgressDialog progressDialog) {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }

    public static void showAlert(Context context, String message, DialogInterface.OnClickListener dialogInterface){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setMessage(message);
        alertDialog.setPositiveButton("ok", dialogInterface);
        alertDialog.show();
    }
}
