package com.example.ridhi.chemophilic.UI;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

import com.example.ridhi.chemophilic.ApiInterface;
import com.example.ridhi.chemophilic.Constants.ApiClient;
import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.adapters.SubjectsAdapter;
import com.example.ridhi.chemophilic.pojo.SubjectPojo;
import com.example.ridhi.chemophilic.utility.Util;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.ridhi.chemophilic.Constants.Constants.ID;

public class Subject extends BaseActivity {
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.recyclerView_sub)
    RecyclerView recyclerView;
    String categoryID;
    private ProgressDialog progressDialog;
    private Call<SubjectPojo> subjectPojoCall;
    private RecyclerView.Adapter adapter;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.subjectlist);
        ButterKnife.bind(this);
        categoryID = String.valueOf(getIntent().getExtras().getString(ID));
        Util.setupToolbarWithoutBack(this, toolbar, getString(R.string.app_name));
        Util.showProgress(progressDialog = new ProgressDialog(this), getString(R.string.loading));
        subjectPojoCall = ApiClient.getApiClient().create(ApiInterface.class).subject(categoryID);
        subjectPojoCall.enqueue(new Callback<SubjectPojo>() {
            @Override
            public void onResponse(@NonNull Call<SubjectPojo> call, @NonNull Response<SubjectPojo> response) {
                Util.dismissProgress(progressDialog);
                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().getObject()!= null && response.body().getObject().size()>0)
                    recyclerView.setAdapter(new SubjectsAdapter(response.body().getObject()));
                } else {
                    Toast.makeText(Subject.this, "Response null from server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<SubjectPojo> call, @NonNull Throwable t) {
                Util.dismissProgress(progressDialog);
                Toast.makeText(Subject.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (subjectPojoCall != null)
            subjectPojoCall.cancel();
    }
}
