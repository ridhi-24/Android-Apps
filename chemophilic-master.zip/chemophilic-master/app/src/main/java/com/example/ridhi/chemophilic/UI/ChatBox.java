package com.example.ridhi.chemophilic.UI;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.example.ridhi.chemophilic.R;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;

import java.net.URISyntaxException;

public class ChatBox extends AppCompatActivity {
    private Socket socket;
    private String chat;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat);
//get chat of the user
        chat = getIntent().getExtras().getString(Chat.chat);
        //connect your socket client  to the server
        try {
            socket = IO.socket("https//192.168.1.16");
            socket.connect();
            // emit the event join along side with the nickname
            socket.emit("join", chat);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }


    }
}

