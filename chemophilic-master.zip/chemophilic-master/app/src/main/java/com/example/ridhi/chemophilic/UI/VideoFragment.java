package com.example.ridhi.chemophilic.UI;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.MediaController;
import android.widget.Toast;

import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.utility.FullScreenMediaController;

import bg.devlabs.fullscreenvideoview.FullscreenVideoView;
import butterknife.BindView;
import butterknife.ButterKnife;

public class VideoFragment extends Fragment implements FullScreenMediaController.FullScreenVideoCallBack {
    @BindView(R.id.myVideo)
    FullscreenVideoView videoview;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.video_view, container, false);
        ButterKnife.bind(this, view);
        Bundle arguments = getArguments();
        if (arguments == null)
            Toast.makeText(getActivity(), "Arguments is NULL", Toast.LENGTH_LONG).show();
        else {
            String url = getArguments().getString("url", "");
            if (url != null)
                playVideo(url);
        }
        return view;
    }

    @Override
    public void navigateToFullScreenVideoScreen() {
        getActivity().finish();
    }

    private void playVideo(String url) {
        try {
            MediaController mediacontroller = new FullScreenMediaController(getActivity(), true, this);
            mediacontroller.setAnchorView(videoview);
            videoview.videoUrl(url);

        } catch (Exception e) {
            e.printStackTrace();
        }
        videoview.requestFocus();
    }
}
