package com.example.ridhi.chemophilic.model;

import java.util.ArrayList;

public class SubjectModel {
  private String headerTitle;
  private ArrayList<CourseModel> items;

    public SubjectModel(String headerTitle, ArrayList<CourseModel> items) {
        this.headerTitle = headerTitle;
        this.items = items;
    }

    public String getHeaderTitle(String s) {
        return headerTitle;
    }

    public void setHeaderTitle(String headerTitle) {
        this.headerTitle = headerTitle;
    }

    public ArrayList<CourseModel> getItems() {
        return items;
    }

    public void setItems(ArrayList<CourseModel> items) {
        this.items = items;
    }
}
