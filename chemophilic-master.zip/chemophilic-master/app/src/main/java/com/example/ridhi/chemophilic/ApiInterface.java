package com.example.ridhi.chemophilic;

import com.example.ridhi.chemophilic.Constants.API;
import com.example.ridhi.chemophilic.pojo.CoursePojo;
import com.example.ridhi.chemophilic.pojo.GenerateCheckSum;
import com.example.ridhi.chemophilic.pojo.LoginPojo;
import com.example.ridhi.chemophilic.pojo.PasswordPojo;
import com.example.ridhi.chemophilic.pojo.RegisterPojo;
import com.example.ridhi.chemophilic.pojo.SubjectPojo;
import com.example.ridhi.chemophilic.pojo.VerifyCheckSum;
import com.example.ridhi.chemophilic.pojo.VideoPojo;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET(API.COURSE)
    Call<CoursePojo> doGetListResources();

    @POST(API.SUBJECT)
    Call<SubjectPojo> subject(@Query("category_id") String categoryID);

    @POST(API.REGISTER)
    Call<RegisterPojo> register(@Query("name") String name,
                                @Query("email") String email,
                                @Query("phone") String phone,
                                @Query("password") String password);

    @POST(API.LOGIN)
    Call<LoginPojo> login(@Query("email") String email, @Query("password") String password);

    @POST(API.VIDEO)
    Call<VideoPojo> video(@Query("subject_id") String Subject,
                          @Query("user_id") String user, @Query("category_id") String category);

    @POST(API.PASSWORD)
    Call<PasswordPojo> password(@Query("email") String email);

    @POST(API.CHECKSUM)
    Call<GenerateCheckSum> genetateCheckSum(@Query("arrayList") String arrayList,
                                            @Query("key") String key);

    @POST(API.CHECKSUMVERIFY)
    Call<VerifyCheckSum> verifyCheckSum(@Query("arrayList") String arrayList);


}
