package com.example.ridhi.chemophilic.adapters.viewholder;

import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ridhi.chemophilic.R;

public class SubjectAdapterViewHolder extends RecyclerView.ViewHolder {
    /*public TextView textview;
    public ImageView imageView;
    public CardView cardView;
    public SubjectAdapterViewHolder(@NonNull View itemView) {
        super(itemView);
        textview=itemView.findViewById(R.id.tvTitle);
        imageView=itemView.findViewById(R.id.itemImage);
        cardView=itemView.findViewById(R.id.card);*/


    public TextView course, courseName;
    public ConstraintLayout mainLayout;
    public ImageView circularImageView;

    public SubjectAdapterViewHolder(@NonNull View itemView) {
        super(itemView);
        /*course = itemView.findViewById(R.id.tv_icon);*/
        courseName = itemView.findViewById(R.id.tv_subject_name);
        circularImageView = itemView.findViewById(R.id.image_view);
        mainLayout = itemView.findViewById(R.id.constant);
    }
}
