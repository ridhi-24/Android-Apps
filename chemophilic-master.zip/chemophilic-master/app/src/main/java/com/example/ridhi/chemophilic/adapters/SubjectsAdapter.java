package com.example.ridhi.chemophilic.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.UI.VideoPlayerActivity;
import com.example.ridhi.chemophilic.adapters.viewholder.SubjectAdapterViewHolder;
import com.example.ridhi.chemophilic.pojo.SubjectPojo;

import java.util.List;

import static com.example.ridhi.chemophilic.Constants.Constants.CATEGORY_ID;
import static com.example.ridhi.chemophilic.Constants.Constants.SUBJECT_ID;

public class SubjectsAdapter extends RecyclerView.Adapter<SubjectAdapterViewHolder> {
    private List<SubjectPojo.Object> list;
    private Context context;

    public SubjectsAdapter(List<SubjectPojo.Object> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public SubjectAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        this.context = viewGroup.getContext();
        return new SubjectAdapterViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.subject, viewGroup,
                false));

    }

    @Override
    public void onBindViewHolder(@NonNull SubjectAdapterViewHolder subjectAdapterViewHolder, final int i) {
        /* ((GradientDrawable) subjectAdapterViewHolder.circularImageView.getBackground()).setColor(context.getResources().getColor(getRandom()));*/
     /*   subjectAdapterViewHolder.course.setText("" + list.get(i).getName().charAt(0));
        subjectAdapterViewHolder.courseName.setText(list.get(i).getName());*/
        // subjectAdapterViewHolder.course.setText(String.valueOf(list.get(i).getName()));
        Glide.with(context).load(String.valueOf(list.get(i).getImage())).into(subjectAdapterViewHolder.circularImageView);
        subjectAdapterViewHolder.courseName.setText(String.valueOf(list.get(i).getName()));
        subjectAdapterViewHolder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, VideoPlayerActivity.class);
                intent.putExtra(SUBJECT_ID, list.get(i).getId());
                intent.putExtra(CATEGORY_ID, list.get(i).getCategoryId());
                context.startActivity(intent);
              }
        });


    }

    /*  public int getRandom() {
          int rnd = new Random().nextInt(color.length);
          return color[rnd];
      }
  */
    @Override
    public int getItemCount() {
        return list.size();
    }
}
