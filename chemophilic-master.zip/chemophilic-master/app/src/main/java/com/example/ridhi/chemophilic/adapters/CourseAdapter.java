package com.example.ridhi.chemophilic.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.UI.Subject;
import com.example.ridhi.chemophilic.adapters.viewholder.CourseAdapterViewHolder;
import com.example.ridhi.chemophilic.pojo.CoursePojo;
import com.example.ridhi.chemophilic.pojo.SubjectPojo;

import java.util.List;

import retrofit2.Call;

import static com.example.ridhi.chemophilic.Constants.Constants.ID;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapterViewHolder> {

    private List<CoursePojo.Object> list;
    private Context context;
    private Call<SubjectPojo> subjectPojoCall;



    public CourseAdapter(List<CoursePojo.Object> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public CourseAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context = viewGroup.getContext();
        this.context = context;
        LayoutInflater inflater = LayoutInflater.from(context);
        View photoView = inflater.inflate(R.layout.row_main_course, viewGroup, false);
        CourseAdapterViewHolder viewHolder = new CourseAdapterViewHolder(photoView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final CourseAdapterViewHolder examHolder, final int i) {

        examHolder.courseName.setText(String.valueOf(list.get(i).getName()));

        examHolder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Subject.class);
                intent.putExtra(ID, String.valueOf(list.get(i).getId()));
                context.startActivity(intent);
            }
        });
      //  examHolder.recyclerView.setLayoutManager(new GridLayoutManager(context, 3));
     //   getSubjects(String.valueOf(list.get(i).getId()), examHolder.recyclerView);

    }


    @Override
    public int getItemCount() {
        return list.size();
    }
/*
    private void getSubjects(final String categoryID, final RecyclerView recyclerView) {
        subjectPojoCall = ApiClient.getApiClient().create(ApiInterface.class).subject(categoryID);
        subjectPojoCall.enqueue(new Callback<SubjectPojo>() {
            @Override
            public void onResponse(@NonNull Call<SubjectPojo> call, @NonNull Response<SubjectPojo> response) {
                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().getObject() != null && response.body().getObject().getData().size() > 0) {
                        recyclerView.setAdapter(new SubjectsAdapter(response.body().getObject().getData()));
                    } else Log.e("error", categoryID);
                } else Log.e("err", categoryID);
            }

            @Override
            public void onFailure(@NonNull Call<SubjectPojo> call, @NonNull Throwable t) {
                Log.e("err_on_failure", t.getMessage());
            }
        });
    }*/
}
