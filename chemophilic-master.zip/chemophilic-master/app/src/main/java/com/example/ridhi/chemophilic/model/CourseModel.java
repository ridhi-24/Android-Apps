package com.example.ridhi.chemophilic.model;

public class CourseModel {
    private String name;
    private String Url;
    private String Description;

    public CourseModel(String name, String url, String description) {
        this.name = name;
        Url = url;
        Description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String url) {
        Url = url;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }
}
