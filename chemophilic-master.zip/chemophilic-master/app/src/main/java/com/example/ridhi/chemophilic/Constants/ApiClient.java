package com.example.ridhi.chemophilic.Constants;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import timber.log.Timber;

/**
 * Created by santosh on 26/4/18.
 */

public class ApiClient {

    private static final String BASE_URL = API.BASE_URL;

    private static Retrofit retrofit = null;

    public static Retrofit getApiClient() {
        if (retrofit == null) {
            Timber.plant(new Timber.DebugTree());

            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
                @Override
                public void log(String message) {
                    Timber.i(message);
                }
            });
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = new OkHttpClient.Builder().addInterceptor(loggingInterceptor)
                    .connectTimeout(20000, TimeUnit.SECONDS).build();
            retrofit = new Retrofit.Builder().baseUrl(BASE_URL).
                    client(client).addConverterFactory(GsonConverterFactory.create()).build();
        }
        return retrofit;
    }
}
