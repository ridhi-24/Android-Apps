package com.example.ridhi.chemophilic;

import com.example.ridhi.chemophilic.pojo.VideoPojo;

import java.io.Serializable;

public interface OnClickListener extends Serializable {
      void onClick(VideoPojo.Object videoPojo);
}
