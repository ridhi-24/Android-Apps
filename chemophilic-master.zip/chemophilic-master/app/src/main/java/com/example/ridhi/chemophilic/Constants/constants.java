package com.example.ridhi.chemophilic.Constants;

public class Constants {
    public static final String MERCHANT_ID = "PNQ5T!KmK79KJs3R";
    public static final String ID = "id";
    public static final String SUBJECT_ID = "subject_id";
    public static final String USER_ID="user_id";
    public static final String CATEGORY_ID ="category_id";
    public static final String PASSWORD="password";
    public static final String CATEGORY_NAME = "category_image";
}
