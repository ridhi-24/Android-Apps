package com.example.ridhi.chemophilic.model;

public class Parent_VideoModel {
    private int image;
    private  String details;
    private int icon;
    private String description;

    public Parent_VideoModel(int image, String details, int icon,String description) {
        this.image = image;
        this.details = details;
        this.icon = icon;
        this.description=description;
    }

    public int getImage() {
        return image;
    }

    public String getDetails() {
        return details;
    }

    public int getIcon() {
        return icon;
    }

    public String getDescription() {
        return description;
    }
}
