package com.example.ridhi.chemophilic.adapters.viewholder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ridhi.chemophilic.R;

public class VideoAdapterViewHolder extends RecyclerView.ViewHolder {
    public TextView video , videoDescription;
    public ImageView iv_course_image, imgLock;
    public LinearLayout linearLayout;

    public VideoAdapterViewHolder(@NonNull View itemView) {
        super(itemView);
        iv_course_image = itemView.findViewById(R.id.iv_course_image);
        video = itemView.findViewById(R.id.video);
        videoDescription = itemView.findViewById(R.id.video_description);
        linearLayout = itemView.findViewById(R.id.layout);
        imgLock = itemView.findViewById(R.id.iv_locked);


    }
}
