package com.example.ridhi.chemophilic.UI;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import com.example.ridhi.chemophilic.R;

public class VideoQuality extends AppCompatActivity {
    CheckBox quality, check, qwerty, btn, text, pan;
    Button ok, cancel;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videoquality);
        quality = findViewById(R.id.quality);
        check = findViewById(R.id.check);
        qwerty = findViewById(R.id.aa);
        btn = findViewById(R.id.pin);
        text = findViewById(R.id.fan);
        pan = findViewById(R.id.pan);
        ok = findViewById(R.id.button);
        cancel = findViewById(R.id.cancel);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), VideoPlayerActivity.class);
                startActivity(intent);
            }
        });


    }
}
