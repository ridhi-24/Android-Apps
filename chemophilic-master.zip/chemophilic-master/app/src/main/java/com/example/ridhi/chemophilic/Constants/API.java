package com.example.ridhi.chemophilic.Constants;

public class API {

   // public static final String BASE_URL = "http://192.168.10.74:80/video-course/public/api/";
    public static final String BASE_URL="http://video.nuagedigitech.com/api/";
    public static final String COURSE = "course";
    public static final String SUBJECT = "subject";
    public static final String REGISTER = "register";
    public static final String LOGIN = "login";
    public static final String VIDEO = "video";
    public static final String PASSWORD = "password/email";
    public static final String CHECKSUM = "cheksum";
    public static final String CHECKSUMVERIFY="verifyCheksum";

}
