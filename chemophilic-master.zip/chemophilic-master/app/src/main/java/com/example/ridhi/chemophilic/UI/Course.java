package com.example.ridhi.chemophilic.UI;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

import com.example.ridhi.chemophilic.ApiInterface;
import com.example.ridhi.chemophilic.Constants.ApiClient;
import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.adapters.CourseAdapter;
import com.example.ridhi.chemophilic.pojo.CoursePojo;
import com.example.ridhi.chemophilic.utility.Util;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Course extends AppCompatActivity {

    @BindView(R.id.recycler_view)
    RecyclerView recyclerView;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.swipe)
    SwipeRefreshLayout swipeRefreshLayout;
    private Call<CoursePojo> coursePojoCall;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);
        ButterKnife.bind(this);
        Util.setupToolbarWithoutBack(this, toolbar, getString(R.string.app_name));
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getCourseData();
            }
        });
        swipeRefreshLayout.setRefreshing(true);
        getCourseData();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (coursePojoCall != null)
            coursePojoCall.cancel();
    }

    private void getCourseData() {
        coursePojoCall = ApiClient.getApiClient().create(ApiInterface.class).doGetListResources();
        coursePojoCall.enqueue(new Callback<CoursePojo>() {
            @Override
            public void onResponse(@NonNull Call<CoursePojo> call, @NonNull Response<CoursePojo> response) {
                swipeRefreshLayout.setRefreshing(false);
                if (response.isSuccessful() && response.body() != null) {
                    CourseAdapter adapter = new CourseAdapter(response.body().getObject());
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(Course.this, "Response null from server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<CoursePojo> call, @NonNull Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                Toast.makeText(Course.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
