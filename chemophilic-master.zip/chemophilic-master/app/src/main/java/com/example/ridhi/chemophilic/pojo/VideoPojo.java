package com.example.ridhi.chemophilic.pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class VideoPojo {
    @SerializedName("object")
    @Expose
    private List<Object> object = null;
    @SerializedName("status")
    @Expose
    private Boolean status;
    @SerializedName("message")
    @Expose
    private String message;

    public List<Object> getObject() {
        return object;
    }

    public void setObject(List<Object> object) {
        this.object = object;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public class Object {

        @SerializedName("title")
        @Expose
        private String title;
        @SerializedName("slug")
        @Expose
        private String slug;
        @SerializedName("description")
        @Expose
        private String description;
        @SerializedName("thumbnail")
        @Expose
        private String thumbnail;
        @SerializedName("category_id")
        @Expose
        private Integer categoryId;
        @SerializedName("subject_id")
        @Expose
        private Integer subjectId;
        @SerializedName("stream_path")
        @Expose
        private String streamPath;
        @SerializedName("is_demo")
        @Expose
        private String isDemo;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getSlug() {
            return slug;
        }

        public void setSlug(String slug) {
            this.slug = slug;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getThumbnail() {
            return thumbnail;
        }

        public void setThumbnail(String thumbnail) {
            this.thumbnail = thumbnail;
        }

        public Integer getCategoryId() {
            return categoryId;
        }

        public void setCategoryId(Integer categoryId) {
            this.categoryId = categoryId;
        }

        public Integer getSubjectId() {
            return subjectId;
        }

        public void setSubjectId(Integer subjectId) {
            this.subjectId = subjectId;
        }

        public String getStreamPath() {
            return streamPath;
        }

        public void setStreamPath(String streamPath) {
            this.streamPath = streamPath;
        }

        public String getIsDemo() {
            return isDemo;
        }

        public void setIsDemo(String isDemo) {
            this.isDemo = isDemo;
        }
    }
}

