package com.example.ridhi.chemophilic.UI;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ridhi.chemophilic.ApiInterface;
import com.example.ridhi.chemophilic.Constants.ApiClient;
import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.pojo.LoginPojo;
import com.example.ridhi.chemophilic.pojo.PasswordPojo;
import com.example.ridhi.chemophilic.utility.Util;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignIn extends AppCompatActivity {
    @BindView(R.id.email)
    EditText email;
    @BindView(R.id.password)
    EditText password;
    @BindView(R.id.register)
    TextView Register;
    @BindView(R.id.forgot)
    TextView Forgot;
    @BindView(R.id.signin)
    TextView Button;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    ProgressDialog progressDialog;
    private Call<LoginPojo> loginPojoCall;
    private Call<PasswordPojo> forgotPasswordCall;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin);
        ButterKnife.bind(this);
        Util.setupToolbarWithoutBack(this, toolbar, getString(R.string.app_name));

        Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailStr = email.getText().toString().trim();
                String PasswordStr = password.getText().toString().trim();
                if (TextUtils.isEmpty(emailStr)
                        || (TextUtils.isEmpty(PasswordStr) && PasswordStr.length() < 7)) {
                    Toast.makeText(SignIn.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                } else {
                    Util.showProgress(progressDialog = new ProgressDialog(SignIn.this), "Successfully login...");
                    loginPojoCall = ApiClient.getApiClient().create(ApiInterface.class)
                            .login(emailStr, PasswordStr);
                    loginPojoCall.enqueue(new Callback<LoginPojo>() {

                        @Override
                        public void onResponse(Call<LoginPojo> call, Response<LoginPojo> response) {
                            Util.dismissProgress(progressDialog);
                            if (response.isSuccessful() && response.body() != null) {
                                if (response.body().getStatus()) {
                                    Util.showAlert(SignIn.this, response.body().getMessage(), null);
                                } else {
                                    Util.showAlert(SignIn.this, response.body().getMessage(), null);

                                }


                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<LoginPojo> call, @NonNull Throwable t) {
                            Util.dismissProgress(progressDialog);
                            Toast.makeText(SignIn.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

        });
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SignUp.class);
                startActivity(intent);
            }
        });
        Forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SignIn.this);
                LayoutInflater inflater = SignIn.this.getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.fpassword, null);
                builder.setView(dialogView);
                final EditText editText = dialogView.findViewById(R.id.email);
                final android.widget.Button button = dialogView.findViewById(R.id.fbutton);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        resetForgetRequest(editText.getText().toString());
                    }
                });
                builder.show();


            }
        });


    }

    private void resetForgetRequest(String s) {
        progressDialog = new ProgressDialog(SignIn.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        forgotPasswordCall = ApiClient.getApiClient().create(ApiInterface.class).password(s);
        forgotPasswordCall.enqueue(new Callback<PasswordPojo>() {
            @Override
            public void onResponse(Call<PasswordPojo> call, Response<PasswordPojo> response) {
                Util.dismissProgress(progressDialog);
                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().getStatus()) {
                        Util.showAlert(SignIn.this, response.body().getMessage(), null);
                    } else {
                        if (response.body() != null) {

                            Toast.makeText(SignIn.this, " null ", Toast.LENGTH_SHORT).show();


                        }

                    }
                } else {
                    Toast.makeText(SignIn.this, "response null in body", Toast.LENGTH_SHORT).show();
                    // Util.showAlert(SignUp.this, stringBuilder.toString(), null);
                }

            }

            @Override
            public void onFailure(Call<PasswordPojo> call, Throwable t) {
                Util.dismissProgress(progressDialog);
                Toast.makeText(SignIn.this, t.getMessage(), Toast.LENGTH_SHORT).show();

            }

        });


    }


}




