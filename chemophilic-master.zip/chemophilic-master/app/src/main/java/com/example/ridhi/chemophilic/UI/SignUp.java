package com.example.ridhi.chemophilic.UI;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ridhi.chemophilic.ApiInterface;
import com.example.ridhi.chemophilic.Constants.ApiClient;
import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.pojo.RegisterPojo;
import com.example.ridhi.chemophilic.utility.Util;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUp extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.name)
    EditText name;
    @BindView(R.id.password)
    EditText password;
    @BindView(R.id.email)
    EditText email;
    @BindView(R.id.phone)
    EditText phone;
    @BindView(R.id.button)
    Button button;
    ProgressDialog progressDialog;


    private Call<RegisterPojo> registerPojoCall;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        ButterKnife.bind(this);
        Util.setupToolbarWithoutBack(this, toolbar, getString(R.string.app_name));
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameStr = name.getText().toString().trim();
                String emailStr = email.getText().toString().trim();
                String phoneStr = phone.getText().toString().trim();
                String passwordStr = password.getText().toString().trim();
                if (TextUtils.isEmpty(nameStr) || TextUtils.isEmpty(emailStr)
                        || TextUtils.isEmpty(phoneStr)
                        || (TextUtils.isEmpty(passwordStr) && passwordStr.length() < 7)) {
                    Toast.makeText(SignUp.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                } else {
                    Util.showProgress(progressDialog = new ProgressDialog(SignUp.this), "Creating Account...");
                    registerPojoCall = ApiClient.getApiClient().create(ApiInterface.class)
                            .register(nameStr, emailStr, phoneStr, passwordStr);
                    registerPojoCall.enqueue(new Callback<RegisterPojo>() {
                        @Override
                        public void onResponse(@NonNull Call<RegisterPojo> call, @NonNull Response<RegisterPojo> response) {
                            Util.dismissProgress(progressDialog);
                            if (response.isSuccessful() && response.body() != null) {
                                if (response.body().getStatus()) {
                                    Util.showAlert(SignUp.this, response.body().getMessage(), null);
                                    startActivity(new Intent(getApplicationContext(), SignIn.class));
                                } else {
                                    Util.showAlert(SignUp.this, response.body().getMessage(), null);
                                }
                            } else {
                                Toast.makeText(SignUp.this, "response null in body", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(@NonNull Call<RegisterPojo> call, @NonNull Throwable t) {
                            Util.dismissProgress(progressDialog);
                            Toast.makeText(SignUp.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}