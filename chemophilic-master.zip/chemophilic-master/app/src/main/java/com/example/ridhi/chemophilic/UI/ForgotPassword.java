package com.example.ridhi.chemophilic.UI;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

import com.example.ridhi.chemophilic.R;

public class ForgotPassword extends AppCompatActivity {
    private EditText email;
    private Button button;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fpassword);
        email = findViewById(R.id.email);
        button = findViewById(R.id.fbutton);



    }
}
