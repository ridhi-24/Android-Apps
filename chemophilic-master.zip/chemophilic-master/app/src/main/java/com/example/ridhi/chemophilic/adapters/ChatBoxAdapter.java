package com.example.ridhi.chemophilic.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.model.Message;

import java.util.List;

class ChatboxAdapter extends RecyclerView.Adapter<ChatboxAdapter.viewHolder> {
    private List<Message> messages;

    public ChatboxAdapter(List<Message> messages) {
        this.messages = messages;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.message,viewGroup,false);
        return new ChatboxAdapter.viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder viewHolder, int i) {
        Message m=messages.get(i);
        viewHolder.Nickname.setText(m.getMessage());
        viewHolder.message.setText(m.getText());

    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    class viewHolder extends RecyclerView.ViewHolder {
        private TextView message;
        private TextView Nickname;

        public viewHolder(@NonNull View itemView, TextView message, TextView nickname) {
            super(itemView);
            this.message = message;
            Nickname = nickname;
        }

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            message=itemView.findViewById(R.id.nickname);
            Nickname=itemView.findViewById(R.id.pp);

        }
    }
}
