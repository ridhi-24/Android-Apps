package com.example.ridhi.chemophilic.UI;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.example.ridhi.chemophilic.ApiInterface;
import com.example.ridhi.chemophilic.Constants.ApiClient;
import com.example.ridhi.chemophilic.OnClickListener;
import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.adapters.VideoAdapter;
import com.example.ridhi.chemophilic.model.CheckSumParams;
import com.example.ridhi.chemophilic.model.CheckSumVerify;
import com.example.ridhi.chemophilic.pojo.GenerateCheckSum;
import com.example.ridhi.chemophilic.pojo.VerifyCheckSum;
import com.example.ridhi.chemophilic.pojo.VideoPojo;
import com.example.ridhi.chemophilic.utility.FullScreenMediaController;
import com.example.ridhi.chemophilic.utility.Util;
import com.google.gson.Gson;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import java.util.HashMap;
import java.util.Random;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.ridhi.chemophilic.Constants.Constants.CATEGORY_ID;
import static com.example.ridhi.chemophilic.Constants.Constants.SUBJECT_ID;
import static com.example.ridhi.chemophilic.Constants.Constants.USER_ID;

public class VideoPlayerActivity extends AppCompatActivity implements OnClickListener, FullScreenMediaController.FullScreenVideoCallBack {
    private static final String TAG = "PayTm";
    private final String merchantKey = "PNQ5T!KmK79KJs3R";
    PaytmPGService Service;
    String Subject_id, user_id = "", category_id;
    String[] aa = {"MID", "ORDER_ID", "CUST_ID", "MOBILE_NO", "EMAIL", "CHANNEL_ID", "TXN_AMOUNT", "WEBSITE", "INDUSTRY_TYPE_ID", "CALLBACK_URL"};
    private VideoAdapter adapter;
    @BindView(R.id.recylerview)
    RecyclerView recyclerView;/*
    @BindView(R.id.myVideo)
    FullscreenVideoView videoview;*/
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    private String orderid;
    private ProgressDialog progressDialog;
    private Call<VideoPojo> videoPojoCall;
    private String paytmChecksum = null;
    private Call<GenerateCheckSum> generateCheckSumCall;
    private Call<VerifyCheckSum> verifyCheckSumCall;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videocourse);
        ButterKnife.bind(this);
        Subject_id = String.valueOf(getIntent().getExtras().getInt(SUBJECT_ID));
        user_id = String.valueOf(getIntent().getExtras().getInt(USER_ID));
        category_id = String.valueOf(getIntent().getExtras().getInt(CATEGORY_ID));
        Util.setupToolbarWithoutBack(this, toolbar, getString(R.string.app_name));
//        startPayment();
        String fullScreen = getIntent().getStringExtra("fullScreenInd");
        if ("y".equals(fullScreen)) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        if (ContextCompat.checkSelfPermission(VideoPlayerActivity.this, Manifest.permission.READ_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(VideoPlayerActivity.this, new String[]{Manifest.permission.READ_SMS,
                    Manifest.permission.RECEIVE_SMS}, 101);
        }
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        Util.showProgress(progressDialog = new ProgressDialog(this), getString(R.string.loading));
        videoPojoCall = ApiClient.getApiClient().create(ApiInterface.class).video(Subject_id, user_id, category_id);
        videoPojoCall.enqueue(new Callback<VideoPojo>() {
            @Override
            public void onResponse(@NonNull Call<VideoPojo> call, @NonNull Response<VideoPojo> response) {
                Util.dismissProgress(progressDialog);
                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().getObject() != null && response.body().getObject().size() > 0) {
                        recyclerView.setAdapter(new VideoAdapter(response.body().getObject(), VideoPlayerActivity.this));
                        if (response.body().getObject().get(0).getIsDemo().equals("1")) {
                            replaceFragment(response.body().getObject().get(0).getStreamPath());
                        } else {
                            Toast.makeText(VideoPlayerActivity.this, "first video is not demo or unlocked", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(VideoPlayerActivity.this, "Response null from server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<VideoPojo> call, @NonNull Throwable t) {
                Util.dismissProgress(progressDialog);
                Toast.makeText(VideoPlayerActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        //generateChecksum();
    }


    private void generateChecksum() {
        Generatecheck();
        final CheckSumParams checkSumParams = (new CheckSumParams("Chemop28900841298801", orderid, "cust222", "7777777777",
                "username@emailprovider.com", "WAP", "100.12", "APPSTAGING",
                "Retail", "https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=" + orderid));
        String json = new Gson().toJson(checkSumParams);
        generateCheckSumCall = ApiClient.getApiClient().create(ApiInterface.class).genetateCheckSum(json,
                com.example.ridhi.chemophilic.Constants.Constants.MERCHANT_ID);
        generateCheckSumCall.enqueue(new Callback<GenerateCheckSum>() {
            @Override
            public void onResponse(@NonNull Call<GenerateCheckSum> call, @NonNull Response<GenerateCheckSum> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Toast.makeText(VideoPlayerActivity.this, "" + response.body().getCheksum(), Toast.LENGTH_SHORT).show();
                    Log.e("checksum:", response.body().getCheksum());
                    startPayment(response.body().getCheksum(), checkSumParams);
                } else {
                    Toast.makeText(VideoPlayerActivity.this, "Response is  null from server", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<GenerateCheckSum> call, @NonNull Throwable t) {
                Toast.makeText(VideoPlayerActivity.this, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    private void Generatecheck() {
        Random r = new Random(System.currentTimeMillis());
        orderid = "ORDER_ID" + (1 + r.nextInt(2)) * 10000 + r.nextInt(10000);
    }

    private void startPayment(String cheksum, CheckSumParams checkSumParams) {
        Service = PaytmPGService.getStagingService();
        // PaytmPGService Service = PaytmPGService.getProductionService();
        HashMap<String, String> paramMap = new HashMap<String, String>();
        paramMap.put("MID", checkSumParams.getMID());
// Key in your staging and production MID available in your dashboard
        paramMap.put("ORDER_ID", checkSumParams.getORDER_ID());
        paramMap.put("CUST_ID", checkSumParams.getCUST_ID());
        paramMap.put("MOBILE_NO", checkSumParams.getMOBILE_NO());
        paramMap.put("EMAIL", checkSumParams.getEMAIL());
        paramMap.put("CHANNEL_ID", checkSumParams.getCHANNEL_ID());
        paramMap.put("TXN_AMOUNT", checkSumParams.getTXN_AMOUNT());
        paramMap.put("WEBSITE", checkSumParams.getWEBSITE());
        paramMap.put("INDUSTRY_TYPE_ID", checkSumParams.getINDUSTRY_TYPE_ID());
// This is the staging value. Production value is available in your dashboard
        paramMap.put("CALLBACK_URL", checkSumParams.getCALLBACK_URL());
        paramMap.put("CHECKSUMHASH", cheksum);
        PaytmOrder Order = new PaytmOrder(paramMap);
        Service.initialize(Order, null);


        Service.startPaymentTransaction(this, true,
                true, new PaytmPaymentTransactionCallback() {
            /*Call Backs*/
            public void someUIErrorOccurred(String inErrorMessage) {
                Log.e(TAG, "UI Error " + inErrorMessage);
                Toast.makeText(getApplicationContext(), "UI Error " + inErrorMessage, Toast.LENGTH_LONG).show();

            }

            public void onTransactionResponse(Bundle inResponse) {
                Log.e(TAG, "Payment Transaction response " + inResponse.toString());
                Toast.makeText(getApplicationContext(), "Payment Transaction response " + inResponse.toString(), Toast.LENGTH_LONG).show();
                String response = inResponse.toString().replace("[", "").replace("{", "")
                        .replace("}", "").replace("]", "");
                String[] strings = response.split(",");
                String status = strings[0].split("=")[1];
                String checksumhash = strings[1].split("=")[1];
                String bankname = strings[2].split("=")[1];
                String orderid = strings[3].split("=")[1];
                String taxamount = strings[4].split("=")[1];
                String txndate = strings[5].split("=")[1];
                String mid = strings[6].split("=")[1];
                String TXNID = strings[7].split("=")[1];
                String RESPCODE = strings[8].split("=")[1];
                String paymentmode=strings[9].split("=")[1];
                String banktxnid=strings[10].split("=")[1];
                String currency=strings[11].split("=")[1];
                String gatewayname=strings[12].split("=")[1];
                String respmsg=strings[13].split("=")[1];

               final CheckSumVerify checkSumVerify=new CheckSumVerify(status,checksumhash,
                       bankname,orderid,taxamount,txndate,mid,
                       TXNID,RESPCODE,paymentmode,banktxnid,currency,
                       gatewayname,respmsg);
                String json = new Gson().toJson(checkSumVerify);
                verifyCheckSumCall = ApiClient.getApiClient().create(ApiInterface.class).verifyCheckSum(json);
                verifyCheckSumCall.enqueue(new Callback<VerifyCheckSum>() {
                    @Override
                    public void onResponse(Call<VerifyCheckSum> call, Response<VerifyCheckSum> response) {
                        if (response.isSuccessful() && response.body() != null) {
                              if(response.body().getStatus()){
                                  Toast.makeText(VideoPlayerActivity.this, "success", Toast.LENGTH_SHORT).show();
                              }
                              else {
                                  Toast.makeText(VideoPlayerActivity.this, "failure", Toast.LENGTH_SHORT).show();
                              }

                        } else {
                            Toast.makeText(VideoPlayerActivity.this, "Response is  null from server", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<VerifyCheckSum> call, Throwable t) {
                        Toast.makeText(VideoPlayerActivity.this, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }

            public void networkNotAvailable() {
                Log.e(TAG, "Network connection error: Check your internet connectivity");
                Toast.makeText(getApplicationContext(), "Network connection error: Check your internet connectivity", Toast.LENGTH_LONG).show();

            }

            public void clientAuthenticationFailed(String inErrorMessage) {
                Toast.makeText(getApplicationContext(), "Authentication failed: Server error" + inErrorMessage.toString(), Toast.LENGTH_LONG).show();
            }

            public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {
                Log.e(TAG, "Unable to load webpage " + inErrorMessage.toString());
                Toast.makeText(getApplicationContext(), "Unable to load webpage " + inErrorMessage.toString(), Toast.LENGTH_LONG).show();

            }

            public void onBackPressedCancelTransaction() {
                Toast.makeText(VideoPlayerActivity.this, "Error on back pressed", Toast.LENGTH_SHORT).show();
            }

            public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {
                Log.e(TAG, "Unable to load webpage " + inErrorMessage);
                Toast.makeText(getApplicationContext(), "Unable to load webpage " + inErrorMessage.toString(), Toast.LENGTH_LONG).show();

            }
        });
    }


    public void onBackPressed() {

        super.onBackPressed();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.settings:
                AlertDialog.Builder builder = new AlertDialog.Builder(VideoPlayerActivity.this);
                builder.setTitle("Select video Quality");
                builder.setAdapter(ArrayAdapter.createFromResource(VideoPlayerActivity.this,
                        R.array.video_quality, android.R.layout.simple_list_item_1), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(VideoPlayerActivity.this, "position clicked " + which, Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
                break;

        }
        return super.onOptionsItemSelected(item);
    }


    private void replaceFragment(String videoUrl) {
        Fragment fragment = new VideoFragment();
        Bundle bundle = new Bundle();
        bundle.putString("url", videoUrl);
        fragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, fragment).commit();
    }

    @Override
    public void onClick(VideoPojo.Object videoPojo) {
        replaceFragment(videoPojo.getStreamPath());
    }

    @Override
    public void navigateToFullScreenVideoScreen() {
        finish();
    }
}


