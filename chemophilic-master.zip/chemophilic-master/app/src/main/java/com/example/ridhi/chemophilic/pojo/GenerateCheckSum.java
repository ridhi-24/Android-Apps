package com.example.ridhi.chemophilic.pojo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GenerateCheckSum {

    @SerializedName("cheksum")
    @Expose
    private String cheksum;

    public String getCheksum() {
        return cheksum;
    }

    public void setCheksum(String cheksum) {
        this.cheksum = cheksum;
    }

}
