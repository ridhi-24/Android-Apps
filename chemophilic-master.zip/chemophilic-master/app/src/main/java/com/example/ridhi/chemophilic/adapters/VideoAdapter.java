package com.example.ridhi.chemophilic.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.example.ridhi.chemophilic.OnClickListener;
import com.example.ridhi.chemophilic.R;
import com.example.ridhi.chemophilic.adapters.viewholder.VideoAdapterViewHolder;
import com.example.ridhi.chemophilic.pojo.VideoPojo;

import java.util.List;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapterViewHolder> {
    private List<VideoPojo.Object> list;
    private Context context;
    private OnClickListener onClickListener;


    public VideoAdapter(List<VideoPojo.Object> list, OnClickListener onClickListener) {
        this.list = list;
        this.onClickListener = onClickListener;
    }

    @NonNull
    @Override
    public VideoAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        this.context = viewGroup.getContext();
        return new VideoAdapterViewHolder(LayoutInflater.from(viewGroup.getContext()).
                inflate(R.layout.parent_index, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VideoAdapterViewHolder videoAdapterViewHolder, final int i) {
        Glide.with(context).load(list.get(i).getThumbnail()).into(videoAdapterViewHolder.iv_course_image);
        videoAdapterViewHolder.video.setText((list.get(i).getTitle()));
        videoAdapterViewHolder.videoDescription.setText((list.get(i).getDescription()));
        videoAdapterViewHolder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (list.get(i).getIsDemo().equals("1"))
                    onClickListener.onClick(list.get(i));
            }
        });
        //videoAdapterViewHolder.imgLock.setVisibility(list.get(i).getIsDemo().equals("0") ? View.VISIBLE : View.INVISIBLE);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}