package com.example.ridhi.chemophilic.model;

public class CheckSumVerify {
    private String STATUS;
    private String CHECKSUMHASH;
    private String BANKNAME;
    private String ORDERID;
    private String TXNAMOUNT;
    private String TXNDATE;
    private String MID;
    private String TXNID;
    private String RESPCODE;
    private String PAYMENTMODE;
    private String BANKTXNID;
    private String CURRENCY;
    private String GATEWAYNAME;
    private String RESPMSG;

    public CheckSumVerify(String STATUS, String CHECKSUMHASH, String BANKNAME, String ORDERID, String TXNAMOUNT, String TXNDATE, String MID, String TXNID, String RESPCODE, String PAYMENTMODE, String BANKTXNID, String CURRENCY, String GATEWAYNAME, String RESPMSG) {
        this.STATUS = STATUS;
        this.CHECKSUMHASH = CHECKSUMHASH;
        this.BANKNAME = BANKNAME;
        this.ORDERID = ORDERID;
        this.TXNAMOUNT = TXNAMOUNT;
        this.TXNDATE = TXNDATE;
        this.MID = MID;
        this.TXNID = TXNID;
        this.RESPCODE = RESPCODE;
        this.PAYMENTMODE = PAYMENTMODE;
       this.BANKTXNID = BANKTXNID;
        this.CURRENCY = CURRENCY;
        this.GATEWAYNAME = GATEWAYNAME;
        this.RESPMSG = RESPMSG;
    }

    public String getSTATUS() {
        return STATUS;
    }

    public String getCHECKSUMHASH() {
        return CHECKSUMHASH;
    }

    public String getBANKNAME() {
        return BANKNAME;
    }

    public String getORDERID() {
        return ORDERID;
    }

    public String getTXNAMOUNT() {
        return TXNAMOUNT;
    }

    public String getTXNDATE() {
        return TXNDATE;
    }

    public String getMID() {
        return MID;
    }

    public String getTXNID() {
        return TXNID;
    }

    public String getRESPCODE() {
        return RESPCODE;
    }

    public String getPAYMENTMODE() {
        return PAYMENTMODE;
    }

    public String getBANKTXNID() {
        return BANKTXNID;
    }

    public String getCURRENCY() {
        return CURRENCY;
    }

    public String getGATEWAYNAME() {
        return GATEWAYNAME;
    }

    public String getRESPMSG() {
        return RESPMSG;
    }
}
