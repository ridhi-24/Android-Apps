package com.example.ridhi.chemophilic.adapters.viewholder;

import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.example.ridhi.chemophilic.R;
import com.github.siyamed.shapeimageview.CircularImageView;

public class CourseAdapterViewHolder extends RecyclerView.ViewHolder {

    /*public  TextView textView;
    public  TextView button;
    public  RecyclerView recyclerView;

    *//*  @BindView(R.id.itemTitle)
    public   TextView textView;
    @BindView(R.id.btnMore)
     public Button button;
    @BindView(R.id.recycler_view_list)
    public RecyclerView recyclerView;*//*
    public CourseAdapterViewHolder(@NonNull View itemView) {
        super(itemView);
        textView=itemView.findViewById(R.id.itemTitle);
        button=itemView.findViewById(R.id.btnMore);
        recyclerView=itemView.findViewById(R.id.recycler_view_list);

    }*/

    public TextView description, courseName;
    public ConstraintLayout mainLayout;
    public CircularImageView imageView;



    public CourseAdapterViewHolder(@NonNull View itemView) {
        super(itemView);
        courseName = itemView.findViewById(R.id.tv_course_name);
        description = itemView.findViewById(R.id.tv_course_description);
        mainLayout = itemView.findViewById(R.id.main_layout);
        imageView = itemView.findViewById(R.id.iv_course_image);



    }
}
