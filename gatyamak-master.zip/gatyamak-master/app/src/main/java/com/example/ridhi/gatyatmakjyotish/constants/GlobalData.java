package com.example.ridhi.gatyatmakjyotish.constants;

import com.example.ridhi.gatyatmakjyotish.pojo.LoginInfo;

public class GlobalData {

    public static LoginInfo loginInfo = null;
}
