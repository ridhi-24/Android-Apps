package com.example.ridhi.gatyatmakjyotish.ui.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.util.Util;

import static com.example.ridhi.gatyatmakjyotish.constants.Constants.LOGIN_PREF;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.TOKEN;

public class FrontScreen extends AppCompatActivity {
   LinearLayout click, signup;
    private android.support.v7.widget.Toolbar toolbar;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frontscreen);
        toolbar = findViewById(R.id.toolbar);
        Util.setupToolbarWithoutBack(this, toolbar, getString(R.string.app_name));
        click = findViewById(R.id.click);
     signup = findViewById(R.id.Signup);

        sharedPreferences = getApplicationContext().getSharedPreferences(LOGIN_PREF, 0); // 0 - for private mode
        if (sharedPreferences.getString(TOKEN, null) != null) {
            Intent intent = new Intent(getApplicationContext(), DashBoard.class);
            startActivity(intent);
            finish();
        }


        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SignUp.class);
                startActivity(intent);
            }
        });


    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.login, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                Intent intent = new Intent(getApplicationContext(), Books.class);
                startActivity(intent);
                return true;
            case R.id.item2:
                Intent intent1 = new Intent(getApplicationContext(), Remedy.class);
                startActivity(intent1);
                return true;
            case R.id.item3:
                Intent intent2 = new Intent(getApplicationContext(), PointstoKnow.class);
                startActivity(intent2);
                return true;
            case R.id.item4:
                Intent intent3 = new Intent(getApplicationContext(), UseofApp.class);
                startActivity(intent3);
                return true;
            case R.id.item5:
                Intent intent4 = new Intent(getApplicationContext(), Team.class);
                startActivity(intent4);
                return true;
            case R.id.item6:
                Intent intent5 = new Intent(getApplicationContext(), Language.class);
                startActivity(intent5);
                return true;
            case R.id.item7:
                Intent intent6 = new Intent(getApplicationContext(), AboutUs.class);
                startActivity(intent6);
                return true;
            case R.id.item8:
                Intent intent7 = new Intent(getApplicationContext(), ContactUs.class);
                startActivity(intent7);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
