package com.example.ridhi.gatyatmakjyotish.ui.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ridhi.gatyatmakjyotish.ModelClass.PublishModel;
import com.example.ridhi.gatyatmakjyotish.OnClickListener;
import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.adapters.RemedyRecyclerAdpter;
import com.example.ridhi.gatyatmakjyotish.pojo.Books;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class Publish extends Fragment {
    private TextView publish;
    private RecyclerView recyclerView;
    private CheckBox checkBox;
    private ImageView imageView, book;
    private List<Books> list;
    private Button button;
    OnClickListener onClickListener;
    List<PublishModel> publishList;
    SharedPreferences sharedPreferences;
    public static final String mypreference = "mypref";


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.publish, container, false);
        sharedPreferences = getActivity().getSharedPreferences(mypreference, Context.MODE_PRIVATE);
        publish = view.findViewById(R.id.textview);
        checkBox = view.findViewById(R.id.checkbox);
        recyclerView = view.findViewById(R.id.recycler_view);
        onClickListener = (OnClickListener) getActivity();
        setAdapter();
        return view;

    }

    private void setAdapter() {
        recyclerView.setAdapter(new RemedyRecyclerAdpter(makeList(), onClickListener));
    }


    public List<PublishModel> makeList() {
        publishList = new ArrayList<>();
        int images[] = {R.drawable.book, R.drawable.book_sangeeta};
        int description[] = {R.string.pubb1, R.string.pubb2};
        int title[] = {R.string.title_book1, R.string.title_book2};
        for (int i = 0; i < images.length; i++) {
            publishList.add(new PublishModel(description[i], images[i], false, title[i], 500));
        }
        getSavedSelection();
        return publishList;

    }



    private void getSavedSelection() {
        List<PublishModel> publishModelList = new ArrayList<>();
        String json = sharedPreferences.getString("cart", "");
        if (!(json != null && json.isEmpty())) {
            Type type = new TypeToken<List<PublishModel>>() {
            }.getType();
            publishModelList = new Gson().fromJson(sharedPreferences.getString("cart", ""), type);
        } else {
        }
        if (publishModelList != null) {
            for (PublishModel obj : publishList) {
                for (PublishModel obj1 : publishModelList) {
                    if (obj.getPublish().equals(obj1.getPublish())) {
                        obj.setValue(true);
                    }
                }
            }
        }
    }
}