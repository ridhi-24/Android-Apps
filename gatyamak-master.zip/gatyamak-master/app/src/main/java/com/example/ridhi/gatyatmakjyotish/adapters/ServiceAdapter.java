package com.example.ridhi.gatyatmakjyotish.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.example.ridhi.gatyatmakjyotish.ModelClass.PublishModel;
import com.example.ridhi.gatyatmakjyotish.OnClickListener;
import com.example.ridhi.gatyatmakjyotish.R;

import java.util.List;

public class ServiceAdapter extends RecyclerView.Adapter<ServiceAdapter.ViewHolder> {
    private List<PublishModel> list;
    private OnClickListener onClickListener;
    Context context;

    public ServiceAdapter(List<PublishModel> list, OnClickListener onClickListener) {
        this.list = list;
        this.onClickListener = onClickListener;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        this.context = viewGroup.getContext();
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_service, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {
        final PublishModel obj = list.get(i);
        viewHolder.checkBox.setText(context.getString(obj.getPublish()));
        viewHolder.checkBox.setChecked(obj.getValue());
        if (onClickListener != null) {
            viewHolder.checkBox.setVisibility(View.VISIBLE);
            viewHolder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked)
                        onClickListener.onClick(obj, true);
                    else onClickListener.onClick(obj, false);

                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
//        TextView textView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.check_service);
//            textView = itemView.findViewById(R.id.textview);
        }
    }
}
