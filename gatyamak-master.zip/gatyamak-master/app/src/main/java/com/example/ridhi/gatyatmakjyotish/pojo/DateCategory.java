package com.example.ridhi.gatyatmakjyotish.pojo;

public class DateCategory {
    private Integer id;
    private String date;
    private String description;

    public DateCategory(String description) {
        this.id = id;
        this.date = date;
        this.description=description;
    }

    public Integer getId() {
        return id;
    }

    public String getDate() {
        return date;
    }
    public String getDescription(){
        return description;
    }
}
