package com.example.ridhi.gatyatmakjyotish.ui.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.adapters.DateAdapter;
import com.example.ridhi.gatyatmakjyotish.constants.Api;
import com.example.ridhi.gatyatmakjyotish.constants.Constants;
import com.example.ridhi.gatyatmakjyotish.pojo.DateCategory;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.LOGIN_PREF;

public class Date extends Fragment {
    SharedPreferences sharedPreferences, languagePreference;
    List<DateCategory> dateCategories = new ArrayList<>();
    private ProgressDialog progressDialog;
    DateAdapter dateAdapter;
    TextView textView;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.date, container, false);
        RecyclerView listViewYear = v.findViewById(R.id.recycler_date);
        listViewYear.setLayoutManager(new LinearLayoutManager(getActivity()));
        listViewYear.setAdapter(dateAdapter = new DateAdapter());
        postnewcomment(getActivity());
        return v;

    }

    private void postnewcomment(final Context context) {
        sharedPreferences = context.getSharedPreferences(LOGIN_PREF, MODE_PRIVATE);
        languagePreference = context.getSharedPreferences("language", MODE_PRIVATE);
        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.DATE_API, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (progressDialog != null && progressDialog.isShowing())
                    progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (languagePreference.getString("language", Constants.Language.ENGLISH.getLanguage()).equals(Constants.Language.
                            ENGLISH.getLanguage())) {
                        boolean error = jsonObject.getBoolean("error");
                        if (error) {
                            JSONObject jsonObject1 = jsonObject.getJSONObject("object");
                            dateCategories.add(new DateCategory(jsonObject1.getString("result_date")));
                            dateCategories.add(new DateCategory(jsonObject1.getString("description")));

                        }

                    }/* else {
                        JSONObject jsonObject1 = jsonObject.getJSONObject("object");
                        dateCategories.add(new DateCategory(jsonObject1.getString("description_hindi")));

                    }*/
                     else {
                        textView.setError(jsonObject.getString("message"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (progressDialog != null && progressDialog.isShowing())
                    progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                return params;

            }


        };
        queue.add(stringRequest);


    }


}
