package com.example.ridhi.gatyatmakjyotish.ui.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toolbar;

import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.ui.activity.DashBoard;
import com.example.ridhi.gatyatmakjyotish.util.ImageViewer;

/**
 * A simple {@link Fragment} subclass.
 */
public class UnderProcess extends Fragment  {
   private Button button;
   private ImageView imageView;
   private Toolbar toolbar;
   private String path;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.sangeetaji, container, false);
        button = view.findViewById(R.id.ok_button);
        imageView=view.findViewById(R.id.pandit);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), ImageViewer.class));
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), DashBoard.class);
                startActivity(intent);
                getActivity().finish();
            }
        });
        return view;
    }
}


