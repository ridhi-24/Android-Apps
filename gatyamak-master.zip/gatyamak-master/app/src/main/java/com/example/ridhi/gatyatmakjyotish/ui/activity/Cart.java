package com.example.ridhi.gatyatmakjyotish.ui.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ridhi.gatyatmakjyotish.ModelClass.PublishModel;
import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.adapters.CartAdapter;
import com.example.ridhi.gatyatmakjyotish.util.Util;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.example.ridhi.gatyatmakjyotish.constants.Constants.EMAIL;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.LOGIN_PREF;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.MOBILE;

public class Cart extends AppCompatActivity implements PaymentResultListener {

    private Toolbar toolbar;
    private RecyclerView recyclerView;
    Button button, cart;
    ImageView imageView;
    List<PublishModel> publishModelList = new ArrayList<>();
    public static int total = 0;
    SharedPreferences sharedPreferences, loginSharedPreferences;
    public static final String mypreference = "mypref";
    LinearLayout empty_cart, total_layout;
    private ProgressDialog progressDialog;
    TextView tv_price;
    CartAdapter cartAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart);
        sharedPreferences = getSharedPreferences(mypreference, Context.MODE_PRIVATE);
        loginSharedPreferences = getSharedPreferences(LOGIN_PREF, Context.MODE_PRIVATE);
        cart = findViewById(R.id.cart);
        toolbar = findViewById(R.id.toolbar);
        tv_price = findViewById(R.id.tv_price);
        button = findViewById(R.id.button);
        recyclerView = findViewById(R.id.recycler_cart);
        Util.setLinearLayoutManagerNestedScroll(this, recyclerView);
        imageView = findViewById(R.id.image_cart);
        empty_cart = findViewById(R.id.cart_empty);
        total_layout = findViewById(R.id.total_layout);

        Util.setupToolbar(this, toolbar, getString(R.string.cart));

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Books.class);
                startActivity(intent);
            }
        });
        getFreshCartItems();

        if (publishModelList != null) {
            cartAdapter = new CartAdapter(publishModelList, new CartAdapter.OnClick() {
                @Override
                public void onClick(int position) {
                    cartAdapter.deleteCartItem(position);
                    calculateTotal();
                    getFreshCartItems();
                }
            });
            recyclerView.setAdapter(cartAdapter);
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog = new ProgressDialog(Cart.this);
                progressDialog.setCancelable(false);
                progressDialog.setMessage("Please wait...");
                progressDialog.show();
                finish();
                startPayment();
            }
        });


    }

    private void getFreshCartItems() {
        Type type = new TypeToken<List<PublishModel>>() {
        }.getType();
        publishModelList = new Gson().fromJson(sharedPreferences.getString("cart", ""), type);
        if (publishModelList != null && publishModelList.size() > 0) {
            calculateTotal();
            empty_cart.setVisibility(View.GONE);
        } else {
            total_layout.setVisibility(View.GONE);
            empty_cart.setVisibility(View.VISIBLE);
        }
    }

    public int calculateTotal() {
        int total = 0;
        for (PublishModel publishModel : publishModelList) {
            total += publishModel.getPrice();
        }
        tv_price.setText("Rs "+ String.valueOf(total));
        return total;
    }

    public void startPayment() {
        /**
         * You need to pass current activity in order to let Razorpay create CheckoutActivity
         */
        final Activity activity = this;

        final Checkout co = new Checkout();

        try {
            JSONObject options = new JSONObject();
            options.put("name", "Razorpay Corp");
            options.put("description", "Demoing Charges");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "https://rzp-mobile.s3.amazonaws.com/images/rzp.png");
            options.put("currency", "INR");

            options.put("amount", calculateTotal() * 100);

            JSONObject preFill = new JSONObject();
            preFill.put("email", loginSharedPreferences.getString(EMAIL, ""));
            preFill.put("contact", loginSharedPreferences.getString(MOBILE, ""));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        Intent intent = new Intent(getApplicationContext(), Payment.class);
        startActivity(intent);
        Toast.makeText(this, "Payment successfully done! " + razorpayPaymentID, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onPaymentError(int code, String response) {
        try {
            Toast.makeText(this, "Payment error please try again", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("OnPaymentError", "Exception in onPaymentError", e);
        }
    }


    @Override
    public boolean onSupportNavigateUp() {
        finishActivty();
        return super.onSupportNavigateUp();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishActivty();
    }

    private void finishActivty() {
        startActivity(new Intent(this, Books.class));
        finish();
    }
}


