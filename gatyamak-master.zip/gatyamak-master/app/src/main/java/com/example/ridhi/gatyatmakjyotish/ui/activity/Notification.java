package com.example.ridhi.gatyatmakjyotish.ui.activity;

import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;

public class Notification extends AppCompatActivity {

 /*   NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.notification_icon)
            .setContentTitle(textTitle)
            .setContentText(textContent)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);*/
}
