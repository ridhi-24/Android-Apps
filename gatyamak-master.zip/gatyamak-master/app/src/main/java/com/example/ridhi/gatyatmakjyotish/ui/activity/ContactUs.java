package com.example.ridhi.gatyatmakjyotish.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.util.Util;

import static com.example.ridhi.gatyatmakjyotish.constants.Constants.EMAIL;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.LOGIN_PREF;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.NAME;

public class ContactUs extends AppCompatActivity {

    private TextView text;
    EditText name,email,message,subject;
    SharedPreferences sharedPreferences;
    Button button;
    private Toolbar toolbar;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact);
        toolbar = findViewById(R.id.toolbar);
        Util.setupToolbar(this, toolbar,"Contact us");
        text=findViewById(R.id.text);
        name=findViewById(R.id.name);
        email=findViewById(R.id.email);
        message=findViewById(R.id.message);
        subject=findViewById(R.id.subject);
        button=findViewById(R.id.contact);
        sharedPreferences = getSharedPreferences(LOGIN_PREF, Context.MODE_PRIVATE);
        String nameStr = sharedPreferences.getString(NAME, "");
        String emailStr = sharedPreferences.getString(EMAIL, "");
        name.setText(nameStr);
        email.setText(emailStr);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),DashBoard.class);
                startActivity(intent);
            }
        });

        toolbar = findViewById(R.id.toolbar);
        Util.setupToolbarWithoutBack(this, toolbar, getString(R.string.Contactus));
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}
