package com.example.ridhi.gatyatmakjyotish.constants;


public class Api {
    public static String USER_ID = "";
    public static final String USER = "user/";
    public static final String CHANGE_PASSWORD = "/change-password";
    public static final String UPDATE = "/update";
    public static final String RESULT="result";

    public static final String BASE_URL = "http://astro.nuagedigitech.com/api/";
    public static final String LOGIN_API = BASE_URL + "user/login";
    public static final String SIGNUP = BASE_URL + "user";
    public static String UPDATE_API = "";
    public static String CHANGEPASSWORD_API = "";
    public static final String FORGOTPASSWORD_API = BASE_URL + "forgot/password";
    public static final String YEAR_API=BASE_URL + "groups";
    public static String YEAR_RESULT_API = "";
    public static final String DATE_API=BASE_URL+"daily-result?user_id=1&result_date=2019-06-25";


}
