package com.example.ridhi.gatyatmakjyotish.ui.activity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.ui.fragment.Date;
import com.example.ridhi.gatyatmakjyotish.ui.fragment.FragmentNavigationDrawer;
import com.example.ridhi.gatyatmakjyotish.ui.fragment.Year;

import java.util.ArrayList;
import java.util.List;

/*import com.example.ridhi.gatyatmakjyotish.Year;*/

public class DashBoard extends AppCompatActivity {
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewpager;
    TextView toolbarTitle;
    private DrawerLayout mDrawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard_base_activity);
        toolbar = findViewById(R.id.toolbar);
        viewpager = findViewById(R.id.viewpager);
        tabLayout = findViewById(R.id.tabs);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        setSupportActionBar(toolbar);
        toolbarTitle = toolbar.findViewById(R.id.toolbar_title);
        toolbarTitle.setText(getString(R.string.app_name));
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        tabLayout.setupWithViewPager(viewpager);
        setupViewPager(viewpager);


        FragmentNavigationDrawer fragmentNavigationDrawer = (FragmentNavigationDrawer) getSupportFragmentManager()
                .findFragmentById(R.id.fragment_navigation_drawer);
        fragmentNavigationDrawer.setUp(R.id.fragment_navigation_drawer, (DrawerLayout) findViewById(R.id.drawer_layout), toolbar);


    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new Date(), getString(R.string.date));
        adapter.addFragment(new Year(), getString(R.string.year));
        viewPager.setAdapter(adapter);
    }

    static class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);

        }

        public CharSequence getPageTitle(int Position) {
            return mFragmentTitleList.get(Position);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    public void youtube(View view){

        watchYoutubeVideo();
    }





    public void watchYoutubeVideo() {
//        Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + id));
        Intent webIntent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/channel/UCAi6aRIvEIswUm2ego5grow"));
        startActivity(webIntent);
        try {
//            startActivity(appIntent);
        } catch (ActivityNotFoundException ex) {
            startActivity(webIntent);
        }
    }

public  void  Facebook(View view){
        watchFacebookVideo();
}
    public void watchFacebookVideo(){
        Intent webIntent=new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.facebook.com/gatyatmak/"));
        startActivity(webIntent);
        try {

        }
        catch (ActivityNotFoundException ex){
            startActivity(webIntent);
        }
    }

    public  void  Instagram(View view){
        watchInstagramvideo();
    }
    public void watchInstagramvideo(){
        Intent webIntent=new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.instagram.com/unique.life.graph/"));
        startActivity(webIntent);
        try {

        }
        catch (ActivityNotFoundException ex){
            startActivity(webIntent);
        }
    }


    public  void  Twitter(View view){
        watchTwitterVideo();
    }
    public void watchTwitterVideo(){
        Intent webIntent=new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://twitter.com/shalinikhanna2?s=03"));
        startActivity(webIntent);
        try {

        }
        catch (ActivityNotFoundException ex){
            startActivity(webIntent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.notification_menu, menu);
        return true;
     }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.notification:
                Toast.makeText(this, " show", Toast.LENGTH_SHORT).show();
                break;
            case R.id.cart:
                Intent intent=new Intent(getApplicationContext(),Cart.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}


