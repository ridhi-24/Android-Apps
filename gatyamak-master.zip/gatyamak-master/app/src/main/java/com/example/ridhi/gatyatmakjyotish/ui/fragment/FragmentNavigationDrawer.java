package com.example.ridhi.gatyatmakjyotish.ui.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.ui.activity.AboutUs;
import com.example.ridhi.gatyatmakjyotish.ui.activity.Books;
import com.example.ridhi.gatyatmakjyotish.ui.activity.Cart;
import com.example.ridhi.gatyatmakjyotish.ui.activity.ContactUs;
import com.example.ridhi.gatyatmakjyotish.ui.activity.FrontScreen;
import com.example.ridhi.gatyatmakjyotish.ui.activity.Payment;
import com.example.ridhi.gatyatmakjyotish.ui.activity.PointstoKnow;
import com.example.ridhi.gatyatmakjyotish.ui.activity.ReferEarn;
import com.example.ridhi.gatyatmakjyotish.ui.activity.Remedy;
import com.example.ridhi.gatyatmakjyotish.ui.activity.Set;
import com.example.ridhi.gatyatmakjyotish.ui.activity.Team;
import com.example.ridhi.gatyatmakjyotish.ui.activity.UseofApp;
import com.example.ridhi.gatyatmakjyotish.ui.activity.UserProfile;
import com.example.ridhi.gatyatmakjyotish.ui.fragmentBase.Blog;

import static com.example.ridhi.gatyatmakjyotish.constants.Constants.EMAIL;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.LOGIN_PREF;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.MOBILE;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.NAME;

public class FragmentNavigationDrawer extends Fragment {

    View containerView;
    Button langbtn;
    DrawerLayout mDrawerLayout;
    ActionBarDrawerToggle mDrawerToggle;
    LinearLayout language, otherServices, payment, blog;
    TextView Users, langselect, service, paid, blo, number, name;
    LinearLayout Settings, logout,about,contact,team, referAndEarn,useofapp,articles,publish_services,marketing,remedy,cart,social;



    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable final Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.navigation_layout, container, false);
        langbtn = view.findViewById(R.id.langbtn);
        Users = view.findViewById(R.id.users);
        referAndEarn = view.findViewById(R.id.refer_and_earn);
        paid = view.findViewById(R.id.paid);
        cart=view.findViewById(R.id.cart);
        social=view.findViewById(R.id.social);
        logout = view.findViewById(R.id.logout);
        number=view.findViewById(R.id.number);
        name = view.findViewById(R.id.name);
        payment = view.findViewById(R.id.payment);
        blog = view.findViewById(R.id.blog);
        Settings = view.findViewById(R.id.setting);
        about=view.findViewById(R.id.about);
        contact=view.findViewById(R.id.contact);
        team=view.findViewById(R.id.team);
        useofapp=view.findViewById(R.id.useofapp);
        articles=view.findViewById(R.id.articles);
        publish_services=view.findViewById(R.id.publish_services);
        marketing=view.findViewById(R.id.marketing);
        remedy=view.findViewById(R.id.remedy);

        sharedPreferences =getActivity().getSharedPreferences(LOGIN_PREF,Context.MODE_PRIVATE);
        String nameStr = sharedPreferences.getString(NAME, "");
        String contactlStr = sharedPreferences.getString(MOBILE, "");
        name.setText(nameStr);
        number.setText(contactlStr);




        Users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), UserProfile.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });

        publish_services.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),Books.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });
       cart.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent =new Intent(getActivity(),Cart.class);
               startActivity(intent);
               mDrawerLayout.closeDrawers();
           }
       });

        remedy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),Remedy.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });

        articles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),PointstoKnow.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });

       contact.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent=new Intent(getActivity(),ContactUs.class);
               startActivity(intent);
               mDrawerLayout.closeDrawers();
           }
       });


        social.setOnClickListener(new View.OnClickListener() {

           @Override
           public void onClick(View v) {
               mDrawerLayout.closeDrawers();


           }

       });
        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Payment.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });

        Settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),Set.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });

        useofapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),UseofApp.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });


        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Blog.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });
        referAndEarn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ReferEarn.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });



        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),AboutUs.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sharedPreferences = getActivity().getSharedPreferences(LOGIN_PREF, Context.MODE_PRIVATE);
                editor = sharedPreferences.edit();
                editor.clear();
                editor.apply();
                Intent intent = new Intent(getActivity(), FrontScreen.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
                getActivity().finish();
            }
        });
        team.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),Team.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            }
        });


        return view;
    }


    public void setUp(int fragmentId, DrawerLayout drawerLayout, final Toolbar toolbar) {
        containerView = getActivity().findViewById(fragmentId);
        mDrawerLayout = drawerLayout;
        mDrawerToggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                getActivity().invalidateOptionsMenu();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                getActivity().invalidateOptionsMenu();
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                toolbar.setAlpha(1 - slideOffset / 2);
            }
        };

        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerLayout.post(new Runnable() {
            @Override
            public void run() {
                mDrawerToggle.syncState();
            }
        });

    }
}
