package com.example.ridhi.gatyatmakjyotish.ui.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.adapters.YearAdapter;
import com.example.ridhi.gatyatmakjyotish.constants.Api;
import com.example.ridhi.gatyatmakjyotish.constants.Constants;
import com.example.ridhi.gatyatmakjyotish.pojo.ResultCategory;
import com.example.ridhi.gatyatmakjyotish.pojo.YearCategory;
import com.example.ridhi.gatyatmakjyotish.util.Util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.ID;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.LOGIN_PREF;

public class Year extends Fragment implements AdapterView.OnItemSelectedListener {
    TextView textView;
    List<YearCategory> yearCategoryList = new ArrayList<>();
    Spinner spinner;
    SharedPreferences sharedPreferences, languagePreference;
    List<ResultCategory> resultCategoryList = new ArrayList<>();
    YearAdapter yearAdapter;
    ProgressDialog progressDialog;


    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.year_fragment, container, false);
        spinner = v.findViewById(R.id.spinner);
        RecyclerView listViewYear = v.findViewById(R.id.recycler_view);
        listViewYear.setLayoutManager(new LinearLayoutManager(getActivity()));
        listViewYear.setAdapter(yearAdapter = new YearAdapter());
        postnewcomment(getActivity());
        return v;

    }

    private void postnewcomment(final Context context) {
        sharedPreferences = context.getSharedPreferences(LOGIN_PREF, MODE_PRIVATE);
        languagePreference = context.getSharedPreferences("language", MODE_PRIVATE);

        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest sr = new StringRequest(Request.Method.POST, Api.YEAR_API, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean status = jsonObject.getBoolean("status");
                    if (status) {
                        JSONArray object = jsonObject.getJSONArray("object");
                        yearCategoryList.clear();
                        for (int i = 0; i < object.length(); i++) {
                            JSONObject c = object.getJSONObject(i);
                            int id = c.optInt("id");
                            String title = c.getString("title");
                            String name = c.getString("name");
                            yearCategoryList.add(new YearCategory(id, name, title));
                        }
                        ArrayAdapter<YearCategory> adapter = new ArrayAdapter<YearCategory>(context, android.R.layout.simple_spinner_item, yearCategoryList) {

                            @NonNull
                            @Override
                            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                                View view = super.getView(position, convertView, parent);
                                TextView textView = view.findViewById(android.R.id.text1);
                                textView.setText(yearCategoryList.get(position).getName());
                                return view;
                            }

                            @Override
                            public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                                View view = super.getDropDownView(position, convertView, parent);
                                TextView textView = view.findViewById(android.R.id.text1);
                                textView.setText(yearCategoryList.get(position).getName());

                                return view;
                            }
                        };
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinner.setAdapter(adapter);
                        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                                Api.YEAR_RESULT_API = Api.BASE_URL + Api.RESULT + "/" + sharedPreferences.getString(ID, "") + "/" + yearCategoryList.get(position).getId();
                                postnewcom(Api.YEAR_RESULT_API, getActivity());
                                // your code here
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parentView) {
                                // your code here
                            }

                        });


                    } else {
                        textView.setError(jsonObject.getString("message"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.e("response: ", response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("language", languagePreference.getString("language", Constants.Language.ENGLISH.getLanguage()).
                        equals(Constants.Language.ENGLISH.getLanguage()) ? Constants.Language.ENGLISH.getLanguage() :
                        Constants.Language.HINDI.getLanguage());
                return params;
            }
        };
        queue.add(sr);
    }


    private void postnewcom(String url, final Context context) {
        Util.showProgress(progressDialog = new ProgressDialog(getActivity()), "Loading...");
        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest sr = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Util.dismissProgress(progressDialog);
                try {
                    resultCategoryList.clear();
                    JSONArray jsonArray = new JSONArray(response);
                    if (languagePreference.getString("language", Constants.Language.ENGLISH.getLanguage()).equals(Constants.Language.ENGLISH.getLanguage())) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            JSONObject original = jsonObject.getJSONObject("original");
                            JSONObject object = original.getJSONObject("object");
                            resultCategoryList.add(new ResultCategory(object.getString("date"),
                                    object.getString("description")));
                        }
                    } else {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            JSONObject original = jsonObject.getJSONObject("original");
                            JSONObject object = original.getJSONObject("object");
                            resultCategoryList.add(new ResultCategory(object.getString("hindi_date"),
                                    object.getString("description_hindi")));
                        }
                    }
                    yearAdapter.setAdapter(resultCategoryList);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Util.dismissProgress(progressDialog);
                Toast.makeText(context, "" + error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

               /* params.put("language", sharedPreferences.getString("language", Constants.Language.ENGLISH.getLanguage()).
                        equals(Constants.Language.ENGLISH.getLanguage()) ? Constants.Language.ENGLISH.getLanguage() :
                        Constants.Language.HINDI.getLanguage());
*/
                return params;
            }
        };
        queue.add(sr);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}

