package com.example.ridhi.gatyatmakjyotish.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.ridhi.gatyatmakjyotish.ModelClass.PublishModel;
import com.example.ridhi.gatyatmakjyotish.OnClickListener;
import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.ui.fragment.Publish;
import com.example.ridhi.gatyatmakjyotish.ui.fragment.Service;
import com.example.ridhi.gatyatmakjyotish.util.Util;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Books extends AppCompatActivity implements OnClickListener {
    private TabLayout tabLayout;
    private ViewPager viewPager;
    Toolbar toolbar;
    Button button;
    List<PublishModel> publishModelList = new ArrayList<>();
    SharedPreferences sharedPreferences;
    public static final String mypreference = "mypref";


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.publish_service_base);
        sharedPreferences = getSharedPreferences(mypreference, Context.MODE_PRIVATE);
        viewPager = findViewById(R.id.viewpager);
        tabLayout = findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
        toolbar = findViewById(R.id.toolbar);
        Util.setupToolbar(this, toolbar, getString(R.string.publish));
        setUpViewPager(viewPager);
        tabLayout.setupWithViewPager(viewPager);
        button = findViewById(R.id.button);
        getFreshCartItems();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.commit();


                editor.putString("cart", new Gson().toJson(publishModelList));
                editor.commit();


                Intent intent = new Intent(Books.this, Cart.class);
                startActivity(intent);
                finish();
            }
        });
        viewPager.setOffscreenPageLimit(2);
    }

    private void setUpViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new Publish(), getString(R.string.publish));
        adapter.addFragment(new Service(), getString(R.string.services));
        viewPager.setAdapter(adapter);
    }

    @Override
    public void onClick(PublishModel publishModel, boolean isChecked) {
        if (isChecked) {
                publishModelList.add(publishModel);

        } else {
            Iterator<PublishModel> iterator = publishModelList.iterator();
            while (iterator.hasNext()) {
                PublishModel publishModel1 = iterator.next();
                if (publishModel1.getPublish().equals(publishModel.getPublish())) {
                    iterator.remove();
                }
            }
        }
    }

    private void getFreshCartItems(){
        String json = sharedPreferences.getString("cart", "");
        if (json != null && json.isEmpty()) {
/*
            Toast.makeText(this, "json is empty", Toast.LENGTH_SHORT).show();
*/
        } else {
            Type type = new TypeToken<List<PublishModel>>() {
            }.getType();
            publishModelList = new Gson().fromJson(sharedPreferences.getString("cart", ""), type);
        }
    }


    static class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);

        }

        public CharSequence getPageTitle(int Position) {

            return mFragmentTitleList.get(Position);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
