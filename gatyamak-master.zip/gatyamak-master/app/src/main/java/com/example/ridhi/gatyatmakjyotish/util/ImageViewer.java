package com.example.ridhi.gatyatmakjyotish.util;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.bogdwellers.pinchtozoom.ImageMatrixTouchHandler;
import com.bumptech.glide.Glide;
import com.example.ridhi.gatyatmakjyotish.R;

public class ImageViewer extends AppCompatActivity {


    ImageView imageView;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.image_view);
        imageView = findViewById(R.id.image_view);
        Glide.with(this).load(getResources().getDrawable(R.drawable.graph)).into(imageView);
        imageView.setOnTouchListener(new ImageMatrixTouchHandler(this));
    }
}
