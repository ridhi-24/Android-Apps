package com.example.ridhi.gatyatmakjyotish.pojo;

public class Books {
    private int image;

    public Books(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }
}
