package com.example.ridhi.gatyatmakjyotish.pojo;

public class ResultCategory {
    private String name;
    private String description;

    public ResultCategory(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "ResultCategory{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
