package com.example.ridhi.gatyatmakjyotish.ui.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.constants.Api;
import com.example.ridhi.gatyatmakjyotish.ui.fragmentBase.Email_base;
import com.example.ridhi.gatyatmakjyotish.util.Util;
import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.BreakIterator;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SignUp extends AppCompatActivity {
    Button btn_SignUp;
    Context context;
    EditText et_Name, et_Dob, et_Tob, et_Pob, et_Loc, et_Mob, et_Email, et_Password, et_Cpass;
    int AUTOCOMPLETE_REQUEST_CODE = 1;
    private ProgressDialog progressDialog;
    RadioGroup radioGroup;
    RadioButton male, female;
    String gender = "male";
    private BreakIterator error;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        et_Name = findViewById(R.id.et_Name);
        et_Dob = findViewById(R.id.et_Dob);
        et_Tob = findViewById(R.id.et_Tob);
        et_Pob = findViewById(R.id.et_Pob);
        et_Loc = findViewById(R.id.et_Loc);
        et_Mob = findViewById(R.id.et_Mob);
        et_Email = findViewById(R.id.et_Email);
        et_Password = findViewById(R.id.et_Password);
        et_Cpass = findViewById(R.id.et_Cpass);
        btn_SignUp = findViewById(R.id.btn_SignUp);
        radioGroup = findViewById(R.id.radio);
        male = findViewById(R.id.rd_Male);
        female = findViewById(R.id.rd_Female);
        et_Pob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME);

                Intent intent = new Autocomplete.IntentBuilder(
                        AutocompleteActivityMode.FULLSCREEN, fields)
                        .build(SignUp.this);
                startActivityForResult(intent, AUTOCOMPLETE_REQUEST_CODE);
            }
        });

        et_Dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Util.setUpDatePicker(et_Dob, SignUp.this).show();
            }
        });

        et_Tob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Util.setUpTimePicker(et_Tob, SignUp.this).show();
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = group.findViewById(checkedId);
                gender = rb.getText().toString();
            }
        });
        btn_SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_Name.getText().toString().equalsIgnoreCase("")) {
                    et_Name.setError("name cant be empty!");
                } else if (et_Dob.getText().toString().equalsIgnoreCase("")) {
                    et_Dob.setError("dob cant be empty!");
                } else if (et_Tob.getText().toString().equalsIgnoreCase("")) {
                    et_Tob.setError("tob cant be empty!");
                } else if (et_Pob.getText().toString().equalsIgnoreCase("")) {
                    et_Pob.setError("pob cant be empty!");
                } else if (et_Loc.getText().toString().equalsIgnoreCase("")) {
                    et_Loc.setError("loc cant be empty!");
                } else if (et_Mob.getText().toString().equalsIgnoreCase("")) {
                    et_Mob.setError("mob cant be empty!");
                } else if (et_Password.getText().toString().equalsIgnoreCase("")) {
                    et_Password.setError("password cant be empty!");
                } else if (et_Cpass.getText().toString().equalsIgnoreCase("")) {
                    et_Cpass.setError("confirm password cant be empty!");
                } else if (et_Email.getText().toString().equalsIgnoreCase("") || !Patterns.EMAIL_ADDRESS.matcher(et_Email.getText().toString()).matches()) {
                    et_Email.setError("invalid email address");
                } else if (!et_Password.getText().toString().equals(et_Cpass.getText().toString())) {
                    Toast.makeText(SignUp.this, "password not matching", Toast.LENGTH_LONG).show();
                } else if (et_Password.getText().toString().length() < 9) {
                    Toast.makeText(SignUp.this, "password should be of minimum 8 characters", Toast.LENGTH_LONG).show();
                } else {
                    progressDialog.show();
                    postNewComment(SignUp.this);
                }


            }
        });
    }


    public void postNewComment(final Context context) {
        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest sr = new StringRequest(Request.Method.POST, Api.SIGNUP, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                Log.e("response: ", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (!jsonObject.optBoolean("status")) {
                        Intent intent = new Intent(getApplicationContext(), Email_base.class);
                        startActivity(intent);
                    } else
                        Toast.makeText(context, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, getString(R.string.no_response), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("name", et_Name.getText().toString().trim());
                params.put("password", et_Password.getText().toString().trim());
                params.put("time_of_birth", et_Tob.getText().toString().trim() + ":00");
                params.put("place_of_birth", et_Dob.getText().toString().trim());
                params.put("current_place", et_Loc.getText().toString().trim());
                params.put("email", et_Email.getText().toString().trim());
                params.put("date_of_birth", et_Dob.getText().toString().trim());
                params.put("gender", gender);
                params.put("mobile", et_Mob.getText().toString().trim());

                return params;

            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }

        };
        queue.add(sr);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Place place = Autocomplete.getPlaceFromIntent(data);
                Log.i("", "Place: " + place.getName() + ", " + place.getId());
            } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
                // TODO: Handle the error.
                Status status = Autocomplete.getStatusFromIntent(data);
                Log.i("", status.getStatusMessage());
            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }
}
