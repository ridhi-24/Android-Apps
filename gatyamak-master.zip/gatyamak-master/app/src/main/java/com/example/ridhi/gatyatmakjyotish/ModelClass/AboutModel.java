package com.example.ridhi.gatyatmakjyotish.ModelClass;

public class AboutModel {
    private String publish;

    public AboutModel(String publish) {
        this.publish = publish;
    }

    public String getPublish() {
        return publish;
    }

}
