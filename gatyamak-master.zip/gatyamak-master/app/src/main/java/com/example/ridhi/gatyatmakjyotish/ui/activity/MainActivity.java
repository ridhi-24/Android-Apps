package com.example.ridhi.gatyatmakjyotish.ui.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.constants.Api;
import com.example.ridhi.gatyatmakjyotish.ui.fragmentBase.Email_base;
import com.example.ridhi.gatyatmakjyotish.util.Util;
import com.google.android.libraries.places.api.Places;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.example.ridhi.gatyatmakjyotish.constants.Constants.CURRENT_PLACE;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.DATE_OF_BIRTH;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.EMAIL;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.EMAIL_VERIFIED_AT;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.GENDER;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.ID;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.LOGIN_PREF;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.MOBILE;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.NAME;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.PLACE_OF_BIRTH;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.TIME_OF_BIRTH;
import static com.example.ridhi.gatyatmakjyotish.constants.Constants.TOKEN;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private EditText email, password;
    private Toolbar toolbar;
    private TextView register, forgot;
    private ProgressDialog progressDialog;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    TextInputLayout inputPassword;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        forgot = findViewById(R.id.forgot);


        Util.setupToolbarWithoutBack(this, toolbar, getString(R.string.app_name));

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            // Write you code here if permission already given.ey
        }


        sharedPreferences = getApplicationContext().getSharedPreferences(LOGIN_PREF, 0); // 0 - for private mode
        if (sharedPreferences.getString(TOKEN, null) != null) {
            Intent intent = new Intent(getApplicationContext(), DashBoard.class);
            startActivity(intent);
            finish();
        }
        editor = sharedPreferences.edit();
        Places.initialize(getApplicationContext(), "AIzaSyAe2JrUxTmyOVrUfhlT-y7HAgxacQaZ4qE");
        button = findViewById(R.id.button);
        inputPassword = findViewById(R.id.input_password);



        /*register = findViewById(R.id.register);*/
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                LayoutInflater inflater = MainActivity.this.getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.forgotpassword, null);
                builder.setView(dialogView);
                final EditText editText = dialogView.findViewById(R.id.email);
                final Button button = dialogView.findViewById(R.id.fbutton);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        resetForgetRequest(editText.getText().toString());
                    }
                });
                builder.show();


            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (email.getText().toString().equalsIgnoreCase("") || !Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
                    email.setError("invalid email address");
                } else if (password.getText().toString().equalsIgnoreCase("")) {
                    password.setError("password cant be empty!");
                } else {
                    postNewComment(MainActivity.this);
                }

            }
        });

}

    private void resetForgetRequest(final String email) {
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        StringRequest sr = new StringRequest(Request.Method.POST, Api.FORGOTPASSWORD_API, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (progressDialog != null && progressDialog.isShowing())
                    progressDialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.optBoolean("status"))
                            Toast.makeText(MainActivity.this, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                Log.e("response: ", response.toString());
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (progressDialog != null && progressDialog.isShowing())
                    progressDialog.dismiss();            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("email", email.trim());
                return params;

            }

        };
        queue.add(sr);
    }


    private void postNewComment(Context context) {
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest sr = new StringRequest(Request.Method.POST, Api.LOGIN_API, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    boolean status = jsonObject.getBoolean("status");
                    if (status) {
                        JSONObject userInfo = jsonObject.getJSONObject("user_info");
                        String token = jsonObject.getString("token");
                        String name = userInfo.getString("name");
                        String place_of_birth = userInfo.getString("place_of_birth");
                        String currenPlace = userInfo.getString("current_place");
                        String email = userInfo.getString("email");
                        String gender = userInfo.getString("gender");
                        String email_verified_at = userInfo.getString("email_verified_at");
                        String id = userInfo.getString("id");
                        String date_of_birth = userInfo.getString("date_of_birth");
                        String time_of_birth = userInfo.getString("time_of_birth");
                        String mobile = userInfo.getString("mobile");

                        editor.putBoolean("KEY_NAME", true);
                        editor.putString(TOKEN, token);
                        editor.putString(NAME, name);
                        editor.putString(PLACE_OF_BIRTH, place_of_birth);
                        editor.putString(CURRENT_PLACE, currenPlace);
                        editor.putString(EMAIL, email);
                        editor.putString(EMAIL_VERIFIED_AT, email_verified_at);
                        editor.putString(ID, id);
                        editor.putString(DATE_OF_BIRTH, date_of_birth);
                        editor.putString(GENDER, gender);
                        editor.putString(TIME_OF_BIRTH, time_of_birth);
                        editor.putString(MOBILE, mobile);
                        editor.apply();
                        Intent intent = new Intent(getApplicationContext(), Email_base.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    } else {
                        inputPassword.setError(jsonObject.getString("message"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.e("response: ", response.toString());
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("email", email.getText().toString().trim());
                params.put("password", password.getText().toString().trim());
                return params;

            }

        };
        queue.add(sr);
    }

}


