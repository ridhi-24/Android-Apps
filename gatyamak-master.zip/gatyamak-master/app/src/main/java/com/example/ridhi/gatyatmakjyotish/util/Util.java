package com.example.ridhi.gatyatmakjyotish.util;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import com.example.ridhi.gatyatmakjyotish.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Util {

    public static void setupToolbar(AppCompatActivity appCompatActivity, Toolbar toolbar, String title) {
        appCompatActivity.setSupportActionBar(toolbar);
        appCompatActivity.getSupportActionBar().setDisplayShowTitleEnabled(false);
// appCompatActivity. getSupportActionBar().setLogo(R.drawable.tatasky);
        appCompatActivity.getSupportActionBar().setDisplayUseLogoEnabled(true);
        Drawable drawable = ContextCompat.getDrawable(appCompatActivity, R.drawable.ic_more_vert_white_24dp);
        toolbar.setOverflowIcon(drawable);
        appCompatActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        appCompatActivity.getSupportActionBar().setDisplayShowHomeEnabled(true);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText(title);
// toolbar.setNavigationIcon();
    }

    public static void setupToolbarWithoutBack(AppCompatActivity appCompatActivity, Toolbar toolbar, String title) {
        appCompatActivity.setSupportActionBar(toolbar);
        appCompatActivity.getSupportActionBar().setDisplayShowTitleEnabled(false);
// appCompatActivity. getSupportActionBar().setLogo(R.drawable.tatasky);
        appCompatActivity.getSupportActionBar().setDisplayUseLogoEnabled(true);
        Drawable drawable = ContextCompat.getDrawable(appCompatActivity, R.drawable.ic_more_vert_white_24dp);
        toolbar.setOverflowIcon(drawable);
        ((TextView) toolbar.findViewById(R.id.toolbar_title)).setText(title);
// toolbar.setNavigationIcon();
    }

    public static TimePickerDialog setUpTimePicker(final EditText editText, Context context) {
        final Calendar newCalendar = Calendar.getInstance();
        int mHour = newCalendar.get(Calendar.HOUR_OF_DAY);
        int mMinute = newCalendar.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog = new TimePickerDialog(context,
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay,
                                          int minute) {
                        editText.setText(String.format("%02d:%02d", hourOfDay, minute));
                    }
                }, mHour, mMinute, true);
        return timePickerDialog;
    }

    public static DatePickerDialog setUpDatePicker(final EditText editText, Context context) {
        final Calendar newCalendar = Calendar.getInstance();
        final SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        DatePickerDialog datePickerDialog = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                newCalendar.set(year, month, dayOfMonth);
                editText.setText(dateFormatter.format(newCalendar.getTime()));
            }
        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        return datePickerDialog;

    }


    public static void setLinearLayoutManagerNestedScroll(Context context, RecyclerView recyclerView) {
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(false);
// addAnimation(context, recyclerView);

    }

    public static void showProgress(ProgressDialog progressDialog, String message) {
        progressDialog.setMessage(message);
        progressDialog.setIndeterminate(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
    }

    public static void dismissProgress(ProgressDialog progressDialog) {
        if (progressDialog != null && progressDialog.isShowing())
            progressDialog.dismiss();
    }
}
