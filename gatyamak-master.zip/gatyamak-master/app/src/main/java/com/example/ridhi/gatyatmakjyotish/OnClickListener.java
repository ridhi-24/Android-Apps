package com.example.ridhi.gatyatmakjyotish;

import com.example.ridhi.gatyatmakjyotish.ModelClass.PublishModel;

import java.io.Serializable;

public interface OnClickListener extends Serializable {
    void onClick(PublishModel publishModel, boolean isChecked);
}
