package com.example.ridhi.gatyatmakjyotish.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.ridhi.gatyatmakjyotish.R;
import com.example.ridhi.gatyatmakjyotish.pojo.DateCategory;
import com.example.ridhi.gatyatmakjyotish.pojo.ResultCategory;
import com.example.ridhi.gatyatmakjyotish.util.SaveTextSize;

import java.util.ArrayList;
import java.util.List;

public class DateAdapter extends RecyclerView.Adapter<DateAdapter.ViewHolder> {
    private Context context;
    private List<DateCategory> dateCategoryArrayList = new ArrayList<>();

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        this.context = viewGroup.getContext();
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.datecategorylist, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        DateCategory obj = dateCategoryArrayList.get(i);
        viewHolder.date.setText(obj.getDate());
        viewHolder.date.setTextSize(TypedValue.COMPLEX_UNIT_PX, SaveTextSize.getInstance(context).getTextSize());
        viewHolder.description.setText(obj.getDescription());
        viewHolder.description.setTextSize(TypedValue.COMPLEX_UNIT_PX, SaveTextSize.getInstance(context).getTextSize());

    }

    @Override
    public int getItemCount() {
        return dateCategoryArrayList.size();
    }

    public void setAdapter(List<DateCategory> dateCategoryArrayList) {
        this.dateCategoryArrayList.clear();
        this.dateCategoryArrayList.addAll(dateCategoryArrayList);
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView date, description;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.text3);
            description = itemView.findViewById(R.id.text4);
        }
    }
}
